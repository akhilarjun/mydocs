var app = angular.module("hackathon-app", []);

app.controller('hackathon-controller', [ '$scope', '$timeout', '$http', function(scope, timeout, $http) {
	/**
	 * YODLEE
	 */
	var yodleeBaseUrl = "https://developer.api.yodlee.com/ysl";

	scope.dummyAccounts = {};
	scope.myAccount = {};
	
	scope.title = 'Dashboard';
	scope.title_desc = 'A Quick Overview';
	
	scope.loader = {
		loadedDummyAccounts : false,
		loadedChandansAccounts : false
	};
	
	var cobrandParam = {
	    "cobrand":      {
	      "cobrandLogin": "sbCobabhishekmjain",
	      "cobrandPassword": "1124317f-09b4-47ee-be0f-c57cb516ac9d",
	      "locale": "en_US"
	     }
	};
	
	var userParam = {
	    "user":      {
	      "loginName": "sbMemabhishekmjain1",
	      "password": "sbMemabhishekmjain1#123",
	      "locale": "en_US"
	     }
	};
	
	var chandanParam = {
		    "user":      {
		      "loginName": "sbMemabhishekmjain2",
		      "password": "sbMemabhishekmjain2#123",
		      "locale": "en_US"
		     }
		};
	var url = yodleeBaseUrl+'/restserver'+'/v1/cobrand/login';
	var userUrl = yodleeBaseUrl+'/restserver'+'/v1/user/login';
	
	var accUrl=yodleeBaseUrl+'/restserver/v1/accounts';
	 $http.post(url,cobrandParam)
	 .then(function successCallback(response) {
			var cobSessionId = {cobSession:response.data.cobrandId};
			var cobSession = "{cobSession="+response.data.session.cobSession+"}";
			var cobSessionForAcc = "cobSession="+response.data.session.cobSession;
			$http({method:'POST', url:userUrl, data:userParam,
				headers: {
					"Content-Type" : "application/json",
					Authorization: cobSession
				}
			})			
			.then(function successCallback(response) {			    
				var userSession = "{"+cobSessionForAcc+','+"userSession="+response.data.user.session.userSession+"}";
				 $http({method:'GET', url:accUrl,
				headers: {
					"Content-Type" : "application/json",
					Authorization: userSession
				}
			})
				 .then(function successCallback(response) {			    
					//console.log("Responce from userAccount final:");
					//console.log(response);
					scope.dummyAccounts.account = response.data.account;
					scope.populateData();
					scope.loader.loadedDummyAccounts = true;
					//Chandans Account
					scope.loader.loadedChandansAccounts = true;
					scope.populateIndiaCard();
					/*$http({method:'POST', url:userUrl, data:chandanParam,
						headers: {
							"Content-Type" : "application/json",
							Authorization: cobSession
						}
					})			
					.then(function successCallback(response) {			    
						var userSession = "{"+cobSessionForAcc+','+"userSession="+response.data.user.session.userSession+"}";
						$http({method:'GET', url:accUrl,
							headers: {
								"Content-Type" : "application/json",
								Authorization: userSession
							}
						})
						.then(function successCallback(response) {			    
							console.log("Responce from chandan final:");
							console.log(response);
							scope.myAccount.account = response.data.account;
							scope.populateIndiaCard();
							scope.loader.loadedChandansAccounts = true;
						},
						function errorCallback(response) {
						});
						
					},
					function errorCallback(response) {
					});*/
				},
				function errorCallback(response) {
				});
				
			},
			function errorCallback(response) {
			});
		  }, function errorCallback(response) {
		  });
	/**
	 * YODLEE END
	 */
	scope.page = {
			showHomePage : true,
			showAddRuleSet : false,
			showNotificationPanel : false
	};
	var createAccountGroups = function (name) {
		return [{
			nameOfAccountGroup : name+' - Payroll',
			listOfAccounts : scope.dummyAccounts.account
		}, {
			nameOfAccountGroup : name+' - Branch Office',
			listOfAccounts : scope.dummyAccounts.account
		}];
	};
	var createCountryList = function (name) {
		return {
			nameOfCountry : name,
			listOfAccountGroups : createAccountGroups(name)
		};
	};
	var listOfCountries = [];
	var shuffle = function (array) {
		var currentIndex = array.length, temp, randomIndex;
		while ( 0 !== currentIndex) {
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex -= 1;
			
			temp = array[currentIndex];
			array[currentIndex] = array[randomIndex];
			array[randomIndex] = temp;
		}
		return array;
	};
	var getCurrencyObj = function (name) {
		return {
			currencyCode : name,
			listOfCountries : shuffle(listOfCountries).slice(0, 3)
		};
	};
	
	scope.currencyArray = [];
	
	scope.currencyArrayToDisplay = ['USD','GBP','EUR','HKD','CHF'];
	
	scope.currencyRates = {};
	
	scope.getExchangeRate = function () {
		$http.get('http://api119105sandbox.gateway.akana.com/fxRates?base=usd')
		.then(function suceesCallback(response){
			
			scope.currencyRates = response.data.rates;
			scope.selectedMainCurrency = 'GBP';
		},function errorCallback(errData){
			console.error("In currency error");
		});
	};
	
	scope.convertCurrency = function () {
		scope.calculateTotal();
	};
	
	scope.populateData = function () {
		listOfCountries = [createCountryList('India'), 
		                       createCountryList('Europe'), 
		                       createCountryList('UK'), 
		                       createCountryList('China')
		                       ,createCountryList('Japan')];
		scope.currencyArray.push(getCurrencyObj('USD'));
		scope.currencyArray.push(getCurrencyObj('GBP'));
	};
	
	scope.populateIndiaCard = function () {
		scope.currencyArray.push({
			currencyCode : 'INR',
			listOfCountries: [{
				nameOfCountry : 'INDIA',
				listOfAccountGroups : [{
					nameOfAccountGroup : 'My Accounts',
					clickable : true,
					listOfAccounts : scope.myAccount.account
				}]
			},createCountryList('China'),createCountryList('Europe')]
		});
	};
	
	/*scope.openAccDetails = function (accountGroup){
		if (accountGroup.clickable) {
			$('#accountDetails').openModal();
		}
	};*/
	
	$('body').on('click', '.menu-handle', function () {
		$('.menu-handle').removeClass('active');
		$(this).addClass('active');
	});
	
	scope.goHome = function () {
		scope.page.showHomePage = true;
		scope.page.showNotificationPanel = false;
		scope.page.showAddRuleSet = false;
		scope.title = 'Dashboard';
		scope.title_desc = 'A Quick Overview';
	};
	
	scope.showAddRuleSet = function () {
		scope.page.showHomePage = false;
		scope.page.showNotificationPanel = false;
		scope.page.showAddRuleSet = true;
		scope.title = 'Rule Set';
		scope.title_desc = 'These rules are not meant to be broken!';
	};
	
	scope.decisionHistory = [{
		fromAccount : '0068413',
		toAccount : '00873315',
		amount : 210530,
		rule : 'Decision#39'
	},{
		fromAccount : '0036831',
		toAccount : '0068120056',
		amount : 8943205,
		rule : 'Decision#3'
	},{
		fromAccount : '0068413',
		toAccount : '1525523',
		amount : 860548,
		rule : 'Decision#59'
	},{
		fromAccount : '05562201',
		toAccount : '0652258',
		amount : 7845555,
		rule : 'Decision#39'
	},{
		fromAccount : '0068413',
		toAccount : '08540660',
		amount : 99520,
		rule : 'Decision#31'
	},{
		fromAccount : '0068413',
		toAccount : '00873315',
		amount : 559222,
		rule : 'Decision#39'
	}];
	
	scope.switchAccount = function (accId, notificationFrom) {
		timeout(function () {
			scope.notificationFrom = notificationFrom;
			scope.page.showHomePage = false;
			scope.page.showNotificationPanel = true;
			scope.page.showAddRuleSet = false;
			scope.event.accountNo = accId;
			scope.title = 'Account Details';
			scope.title_desc = 'It\'s Your Time To Take A Action';
		});
	};
	
	scope.getExchangeRate();
	
	scope.aggregatedTotal = 0;
	
	scope.calculateTotal = function () {
		var total = 0;
		for (var i = 0;scope.currencyArray && i< scope.currencyArray.length; i++) {
			var listOfCountries = scope.currencyArray[i].listOfCountries;
			for (var j = 0;listOfCountries && j< listOfCountries.length;j++) {
				var listOfAccountGroups = listOfCountries[j].listOfAccountGroups;
				for (var k=0;listOfAccountGroups && k< listOfAccountGroups.length;k++) {
					var listOfAccounts = listOfAccountGroups[k].listOfAccounts;
					for (var l=0;listOfAccounts && l< listOfAccounts.length; l++) {
						if (listOfAccounts[l].balance && listOfAccounts[l].balance.amount){
							total = total + listOfAccounts[l].balance.amount;
						};
					}
				}
			}
		}
		if(scope.selectedMainCurrency != 'USD'){
			total = total * scope.currencyRates[scope.selectedMainCurrency];
		}
		total = Math.round(total);
		return total;
	};
	
	scope.highPriorityNotifs = ['0014533','0009832'];
	scope.mediumPriorityNotifs = ['0064632','0068431'];
	scope.lowPriorityNotifs = ['0084321','0034823'];
	
	scope.event = {};
	scope.event.toAccountNo = '0002514896';
	scope.event.toLaggingAccountNo = '008524236';
	
	scope.ammendTheRule = function () {
		$('#ammendRule').openModal();
	};
	
	scope.openDecisionHistory = function () {
		$('#decisionHistory').openModal();
	};
	
	scope.executeAndDismiss = function () {
		if (scope.notificationFrom == 'fromHigh') {
			for (var index = 0; index < scope.highPriorityNotifs.length; index++) {
				if (scope.highPriorityNotifs[index] == scope.event.accountNo) {
					scope.highPriorityNotifs.splice(index, 1);
				}
			}
		} else if (scope.notificationFrom == 'fromMedium') {
			for (var index = 0; index < scope.mediumPriorityNotifs.length; index++) {
				if (scope.mediumPriorityNotifs[index] == scope.event.accountNo) {
					scope.mediumPriorityNotifs.splice(index, 1);
				}
			}
		} else if (scope.notificationFrom == 'fromLow') {
			for (var index = 0; index < scope.lowPriorityNotifs.length; index++) {
				if (scope.lowPriorityNotifs[index] == scope.event.accountNo) {
					scope.lowPriorityNotifs.splice(index, 1);
				}
			}
		}
		scope.goHome();
	};
} ]);